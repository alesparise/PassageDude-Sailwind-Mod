﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;
//poorly written by pr0skynesis (discord username)

// STUFF TO REMEMBER:
//• There is code to add stuff to island scenery;
//• There is code to manage UIs;
//• There is code to load and save data from the GameState.modData dictionary;

namespace PassageDude
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class PassageDudeMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.passagedude";
        public const string pluginName = "Passage Dude";
        public const string pluginVersion = "1.0.0";

        //config file info
        public static ConfigEntry<float> localPriceMultiplierConfig;
        public static ConfigEntry<float> worldPriceMultiplierConfig;

        //variables
        private static AssetBundle bundle;
        private static string assetPath;
        public static GameObject[] dudesPrefab = new GameObject[33]; //array will contain dudes prefabs
        public static GameObject smallUI; //the ui that shows when you click on the passageDude book
        public static GameObject largeUI; //the big ui with the book bg etc...
        public static Texture oceanMap;
        public static Texture alAnkhMap;
        public static Texture emeraldMap;
        public static Texture aestrinMap;
        public static Texture lagoonMap;

        private void Start()    //Load the bundle
        {   
            assetPath = Paths.PluginPath + "\\PassageDude\\passagedude";
            bundle = AssetBundle.LoadFromFile(assetPath);
            if (bundle == null )
            {
                Debug.LogError("PassageDude: Bundle not loaded! Did you place it in the correct folder?");
            }
        }
        public void Awake()
        {
            SceneManager.sceneLoaded += SceneLoaded;

            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(IslandStreetlightsManager), "Awake");
            MethodInfo patch = AccessTools.Method(typeof(PassageDudePatches), "Awake_Patch");
            MethodInfo original2 = AccessTools.Method(typeof(IslandHorizon), "RegisterLoadingFinished");
            MethodInfo patch2 = AccessTools.Method(typeof(PassageDudePatches), "LoadIsland");
            MethodInfo original3 = AccessTools.Method(typeof(IslandHorizon), "DoUnloadScene");
            MethodInfo patch3 = AccessTools.Method(typeof(PassageDudePatches), "UnloadIsland");

            //Create config file in BepInEx\config\
            localPriceMultiplierConfig = Config.Bind("A) Price Multipliers", "localPriceMultiplier", 1.0f, "Adjusts how expensive local passages are. Default is 1.0, set to less than 1 for cheaper passages, set to more than 1 for more expensive passages. E.g.: 0.6 will make passages cost 60% of the original price");
            worldPriceMultiplierConfig = Config.Bind("A) Price Multipliers", "worldPriceMultiplier", 1.0f, "Adjusts how expensive world passages are. Default is 1.0, set to less than 1 for cheaper passages, set to more than 1 for more expensive passages. E.g.: 0.6 will make passages cost 60% of the original price");

            //apply patches
            harmony.Patch(original, new HarmonyMethod(patch));
            harmony.Patch(original2, new HarmonyMethod(patch2));
            harmony.Patch(original3, new HarmonyMethod(patch3));
        }
        private static void SceneLoaded(Scene scene, LoadSceneMode loadSceneMode)
        {
            if (scene.name == "the ocean")
            {
                SetupThings();
            }
            else
            {
                //Debug.LogError("PassageDude: Scene not loaded");
            }
        }
        private static void SetupThings()
        {   //Assigns the bundle content to the correct objects
            if (bundle != null)
            {
                //load the dudes prefabs
                for (int i = 0; i < dudesPrefab.Length; i++)
                {   
                    string prefabPath = $"Assets/PassageDude/passageDude_{i}.prefab";
                    if (bundle.Contains(prefabPath))
                    {
                        dudesPrefab[i] = bundle.LoadAsset<GameObject>(prefabPath);
                    }
                    else
                    {
                        dudesPrefab[i] = null;
                    }
                }
                //load the UI
                smallUI = bundle.LoadAsset<GameObject>("Assets/PassageDude/Prefabs/ferry_hire_UI.prefab");
                if (smallUI == null)
                {
                    Debug.LogError("PassageDude: smallUI NOT loaded correctly.");
                }
                largeUI = bundle.LoadAsset<GameObject>("Assets/PassageDude/Prefabs/largeUIAnchor.prefab");
                if (largeUI == null)
                {
                    Debug.LogError("PassageDude: largeUI NOT loaded correctly.");
                }
                //load map textures
                oceanMap = bundle.LoadAsset<Texture>("Assets/PassageDude/Textures/oceanMap.png");
                alAnkhMap = bundle.LoadAsset<Texture>("Assets/PassageDude/Textures/alAnkhMap.png");
                emeraldMap = bundle.LoadAsset<Texture>("Assets/PassageDude/Textures/emeraldMap.png");
                aestrinMap = bundle.LoadAsset<Texture>("Assets/PassageDude/Textures/aestrinMap.png");
                lagoonMap = bundle.LoadAsset<Texture>("Assets/PassageDude/Textures/lagoonMap.png");
            }
            else
            {
                Debug.LogError("PassageDude: Bundle not loaded correctly.");
            }
        }
    }
    public class PassageDudePatches
    {
        static bool[] loadedIslands = new bool[Refs.islands.Length]; //stores which island is loaded
        static bool[] dudeSpawned = new bool[Refs.islands.Length];  //stores if we spawned a dude on a certain island
        public static bool[] hasDude = {    //stores wheter this island has a dude working here or not
            false,  // 0 null
            //Al Ankh (except Oasis)
            true,   // 1 Gold Rock
            true,   // 2 Al Nilem
            true,   // 3 Neverdin
            true,   // 4 Albacore
            false,  // 5 Clear Mind
            false,  // 6 Lion's Fang
            false,  // 7 Alchemist
            false,  // 8 Academy
            //Emerald
            true,   // 9 Dragon Cliff
            false,  // 10 Sanctuary
            true,   // 11 Crab Beach
            true,   // 12 New Port
            true,   // 13 Sage Hills
            false,  // 14 null
            //Aestrin (and Oasis)
            true,   // 15 Fort Aestrin
            true,   // 16 Sunspire
            true,   // 17 Mt. Malefic
            true,   // 18 Happy Bay
            true,   // 19 Siren Song
            true,   // 20 Oasis
            true,   // 21 Siren Song
            false,  // 22 Serpent Isle
            false,  // 23 Oracle
            false,  // 24 null
            false,  // 25 Chronos
            //Fire Fish Lagoon
            true,   // 26 Fire Fish Town
            true,   // 27 Kicia Bay
            false,  // 28 Senna
            false,  // 29 Onna
            false,  // 30 null
            false,  // 31 fisherman
            false,  // 32 Rock of Despair
        };
        public static bool justTeleported;

        static GameObject[] dudes = new GameObject[Refs.islands.Length]; //stores the instantiated dudes

        [HarmonyPostfix]
        public static void LoadIsland(IslandHorizon __instance)
        {   //Detects when an Island is loaded -> Adds it to the list of loaded islands
            int index = __instance.islandIndex;
            if (GameState.playing || GameState.currentlyLoading || GameState.sleeping)
            {   //this let us skip the scene in the starting menu.
                for (int i = 0; i < Refs.islands.Length; i++)
                {
                    if (Refs.islands[i] != null)
                    {
                        if (i == index)
                        {
                            loadedIslands[i] = true;
                            //Debug.LogWarning($"PassageDude: island #{i}: {Refs.islands[i].name} loadedStatus: {loadedIslands[i]} ← Island loaded!");
                        }
                        else
                        {
                            if (dudeSpawned[i] == true || index == 31)
                            {
                                //Debug.LogWarning($"PassageDude: Island #{i} has a dude, so we don't set it as false loaded yet!");
                            }
                            else
                            {
                                loadedIslands[i] = false;
                            }
                            //Debug.LogWarning($"PassageDude: island #{i}: {Refs.islands[i].name} loadedStatus: {loadedIslands[i]}");
                        }
                    }
                    else
                    {
                        //Debug.LogWarning($"PassageDude: island #{i}: null");
                    }
                }
            }
            else
            {
                return;
            }
        }
        [HarmonyPrefix]
        public static void UnloadIsland(IslandHorizon __instance)
        {   //Detects when an island is unloaded -> mark it as unloaded in the loadedIslands array and calls KillDude
            int index = __instance.islandIndex;

            if (GameState.playing || GameState.currentlyLoading || GameState.sleeping)
            {   //this let us skip the scene in the starting menu.
                for (int i = 0; i < Refs.islands.Length; i++)
                {
                    if (Refs.islands[i] != null)
                    {
                        if (i == index)
                        {
                            DespawnDude(index);
                            loadedIslands[i] = false;
                            //Debug.LogWarning($"PassageDude: island #{i}: {Refs.islands[i].name} loadedStatus: {loadedIslands[i]} ← Island Unloaded!");
                        }
                        else
                        {
                            //Debug.LogWarning($"PassageDude: island #{i}: {Refs.islands[i].name} loadedStatus: {loadedIslands[i]}");
                        }
                    }
                    else
                    {
                        //Debug.LogWarning($"PassageDude: island #{i}: null");
                    }
                }
            }
        }
        [HarmonyPostfix]
        public static void Awake_Patch(IslandStreetlightsManager __instance)
        {   //find the target island to load the dude in and calls the spawn dude function if necessary
            //basically contains the logic to decide wheter to spawn the dude.

            IslandSceneryScene island = __instance.transform.GetComponent<IslandSceneryScene>();
            int index = island.parentIslandIndex;
            if (island != null)
            {
                if (dudeSpawned[index])
                {   //this is the case where we already spawned a dude
                    //Debug.LogError($"NOT spawning Dude in {island.name}, with index {index} because it already has a dude spawned!");
                    return;
                }
                else
                {   //in this case we don't have spawned a dude, so we do and register we done so in the dudeSpawned array
                    //Debug.LogWarning($"PassageDude: island is {island.name} and index {index}, loadedStatus is {loadedIslands[index]}");
                    if (loadedIslands[index])
                    {   //spawn dude!
                        SpawnDude(__instance.transform, index);
                        dudeSpawned[index] = true;
                        //Debug.LogWarning($"PassageDude: Spawning Dude in {island.name}, with index {index} because loadedStatus is {loadedIslands[index]}...");
                    }
                    else
                    {   //island is not loaded actually, so don't spawn dude (skips the start menu)
                        //Debug.LogError($"PassageDude: NOT spawning Dude in {island.name}, with index {index} because loadedStatus is {loadedIslands[index]}...");
                    }
                }
            }
        }
        public static void SpawnDude(Transform position, int index)
        {   //spawn the dude in the correct place
            if (hasDude[index])
            {   //Means the island has a dude working here, so it should be spawned in the scene
                dudes[index] = Object.Instantiate(PassageDudeMain.dudesPrefab[index], position);
                if (dudes[index] != null)
                {
                    //Debug.LogWarning($"PassageDude: dudes[{index}] instantiated. Position: {dudes[index].transform.localPosition}");
                    SmallUI.passageIndex = index;
                    SmallUI.dudeTransform = dudes[index].transform;
                    dudes[index].AddComponent<SmallUI>();
                    //DEBUG: currently: passageDude_prefab>Stand (2) > ferryUI_anchor (0)> ferryUI (0)> ferry_book (0)
                    Transform ferryBook = dudes[index].transform.GetChild(2).GetChild(0).GetChild(0).GetChild(0);
                    
                    if (ferryBook != null)
                    {
                        ferryBook.gameObject.AddComponent<GPButtonBook>();
                        ferryBook.GetComponent<GPButtonBook>().dudeTransform = dudes[index].transform;
                        ferryBook.GetComponent<GPButtonBook>().description = "Open passage offers";
                        if (ferryBook.GetComponent<GPButtonBook>() == null)
                        {
                            //Debug.LogError($"PassageDude: Failed to add script index and transform to the ferry_book of dude #{index}");
                        }
                    }
                    else
                    {
                        //Debug.LogError($"PassageDude: ferry_book is null for dude #{index}");
                    }
                }
                else
                {
                    //Debug.LogError($"PassageDude: dudes[{index}] not instantiated correctly.");
                }
            }
            else
            {
                //Debug.LogError($"PassageDude: No PassageDude works here...");
            }
            //Restore GameState.Recovering. This is useful to ensure instant world shifting
            if (justTeleported && GameState.recovering)
            {
                GameState.recovering = false;
                justTeleported = false;
            }
        }
        public static void DespawnDude(int index)
        {   //remove the dude when the island is unloaded
            if (loadedIslands[index])
            {   //island is loaded?
                if (dudeSpawned[index])
                {   //if there is a dude in the index island, despawn them
                    Object.Destroy(dudes[index]);
                    dudeSpawned[index] = false;
                }
                else
                {   //island does not have a dude (start menu shenanigans and island with no dude)
                    //Debug.LogError("PassageDude: DespawnDude, island does not actually have a dude, doing nothing.");
                }
            }
            else
            {   //island is not actually loaded (start menu shenanigans)
                //Debug.LogError("PassageDude: DespawnDude, island is not actually loaded, doing nothing.");
            }
        }
    }
    public class SmallUI : MonoBehaviour
    {   //for instantiating the UI stuff, controls the small UI, the UI opening and closing
        
        public static GameObject smallUI;
        public static GameObject largeUI;
        public static Transform dudeTransform; //dude position in the scene (needed to spawn the UI in the right place)

        public static int passageIndex;  //dude index, needed to know in which port you are
        public static bool instantiatedUI;
        //public static SmallUI instance;
        private void Awake()
        {   //instantiates the largeUI and smallUI
            if (!instantiatedUI)
            {
                InstantiateUI();
                instantiatedUI = true;
            }
        }
        private static void InstantiateUI()
        {   //initialise all the UI stuff and instantiate it here
            Transform transform = Refs.shiftingWorld;
            //smallUI
            smallUI = Instantiate(PassageDudeMain.smallUI, transform);
            smallUI.transform.GetChild(0).GetChild(0).GetChild(0).gameObject.AddComponent<SmallUIButton>();
            //largeUI
            largeUI = Instantiate(PassageDudeMain.largeUI, transform);
            largeUI.AddComponent<LargeUI>();
            LargeUI.AddButtonComponents();

            if (smallUI != null && largeUI != null)
            {
                largeUI.SetActive(false);
                smallUI.SetActive(false);
            }
            else
            {
                Debug.LogError("PassageDude: smallUI or LargeUI not instantiated correctly");
            }
        }
        public static void ShowSmallUI(Transform passageDude)
        {   //shows the smallUI
            smallUI.SetActive(true);
            smallUI.transform.position = passageDude.position;
            smallUI.transform.rotation = passageDude.rotation;
            UISoundPlayer.instance.PlayUISound(UISounds.smallPop, 0.75f, 1f);
        }
        public static void HideSmallUI()
        {   //hides the UI
            smallUI.SetActive(false);
        }
        public static void OpenBook()
        {   //open the book UI for the PassageDude;
            LargeUI.passageIndex = passageIndex;
            LargeUI.OpenLargeUI();
        }
        public void OnTriggerExit(Collider other)
        {   //Closes the smallUI when walking away
            if (other.CompareTag("Player") && instantiatedUI)
            {
                HideSmallUI();
            }
        }
    }
    public class LargeUI : MonoBehaviour
    {   //contains everything related to the LargeUI (the book where you pick the passage)
        //contains most of the actual code to generate and manage passage offers
        
        //BASE VARIABLES
        public static int passageIndex;     //as always, needed to know where the dude is
        private static int portIndex;       //the index of the port the dude is in, this gets calculated from passageIndex
        
        //TEXT
        private static TextMesh[] allText;
        private static TextMesh originPort;
        private static TextMesh destinationPort;
        private static TextMesh cost;
        private static TextMesh time;  // will be given in a range e.g. 5-9 days
        private static TextMesh risk;  // a %, it will determine whether the passage will take more or less time. Based on the ship / boat used, the distance to the target and maybe the target regiion? (Emerald>FFL>Aestrin>Al'Ankh)
        private static TextMesh distance;  //distance
        private static TextMesh passageName;   //the title of the right page
        private static TextMesh notEnough; //warning message for when the player does not have enough money, activate when needed
        private static TextMesh passage0text;  //the available passages
        private static TextMesh passage1text;
        private static TextMesh passage2text;
        private static TextMesh passage3text;
        private static TextMesh passage4text; 
        private static TextMesh portName; //The current Port name (shown in the "Welcome to message"
        private static TextMesh approximateLocation;
        private static TextMesh noGlobalPassages;

        //UI MANAGEMENT
        public static GameObject largeUI;   //the largeUI gameobject
        public static bool localOffers = true; //displays local offers if true, world offers if false
        public static int selectedPassage; //0 - 4 indicate what passage is currently selected to display it in the right page
        private static Transform player;   //the camera transform, we attach the largeUI to this
        private static Vector3 mapZoomedPos = new Vector3(0.6f, 0.1f, 2.2f);   //position of the zoomed map
        private static Vector3 mapPos; //base position of the zoomed map

        //MATERIALS (for local / world buttons)
        public static Material activeMat;
        public static Material inactiveMat;

        //PASSAGE MANAGEMENT
        public static bool generatedPassages; //remembers if the passages list has already been generated
        public static FerryPassage[] passages = new FerryPassage[10]; //5 local passages and 5 global ones (at most)
        public static string[] truncatedCodes = new string[10]; //as above, these are not the whole codes, they miss the offerNumber and expiration day! They only contain the origin, destination, boat and isGlobal!
        public static string[] passageCodes = new string[10]; //for the full codes, used for saving the passages
        public static ModDataManager modDataManager = new ModDataManager(PassageDudeMain.pluginGuid);   //manage the loading and saving of passageCodes
        private static bool isMajor;    //to know if we should allow more passages and world passages

        //MONOBEHAVIOUR SPECIAL METHODS
        private void Awake()
        {   //initialises text values, calculates the PortIndex from the passageIndex
            largeUI = SmallUI.largeUI;
            passageIndex = SmallUI.passageIndex;
            //FIND PORT INDEX OF CURRENT ISLAND
            FerryIndexToPortIndex();
            if (portIndex == 0 || portIndex == 9 || portIndex == 15 || portIndex == 23 || portIndex == 6 || portIndex == 20)
            {   //in GRC, DC, FA, FFT, Oasis, HB we allow global passages and more passages
                isMajor = true;
            }
            else
            {
                isMajor = false;
            }
            InitialiseText();
            player = Refs.ovrCameraRig;
            for ( int i = 0; i < passages.Length; i++ )
            {   //initialising the FerryPassages
                passages[i] = new FerryPassage();
            }
            LoadPassagesData();
        }
        
        //PASSAGES GENERATION AND MANAGEMENT
        private static void GetAvailablePassages(bool noLocal, bool noGlobal)
        {   //this is called when opening the largeUI. If passages already exist, it loads them, otherwise, it generates them.
            int minPassages = 2;
            int maxPassages = 3;
            int maxAttempts = 8;    //max number of attempts to generate a unique passage before giving up
            float passageChance = 0.3f; //how likely to have passages above minimum available
            string code;

            if (isMajor)
            {   //extra passages and more likely to have them
                minPassages += 1;
                maxPassages += 2;
                maxAttempts = 12;
                passageChance += 0.2f; 
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {   //make the global passages null just in case
                    passages[9 - i] = null; 
                }
            }
            //GET PASSAGES:
            if (!generatedPassages)
            {   //not generated any passages yet, so do that now
                if (isMajor && !noGlobal)
                {   //if it is a capital and if we want global passages
                    int globalOfferNumber = 5;
                    int nullGlobalOffers = 0;
                    for (int i = 0; i < maxPassages; i++)
                    {
                        if (i < minPassages || Random.value < passageChance)
                        {   //generates a passage if we are below the minimum number of passages OR if the chances are good
                            code = UniquePassage(globalOfferNumber, 1, maxAttempts);
                            if (code != null)
                            {   //if the code is unique and good (not null) we save the passage in the passages array
                                PassageFromCode(code);
                                globalOfferNumber++;
                            }
                            else
                            {   //if the code is null it means we did not get a unique code in the maxAttempts, so we make it null
                                nullGlobalOffers++;
                            }
                        }
                        else
                        {
                            nullGlobalOffers++;
                        }
                    }
                    for (int i = 0; i < nullGlobalOffers; i++)
                    {   //make sure the empty offers are actually null (and not just zeroes, which work in the ui...)
                        passages[9 - i] = null;
                    }
                }
                if (!noLocal)
                {
                    //generate local passages
                    int localOfferNumber = 0;    //we only add to this when successfully generating a passage.
                    int nullLocalOffers = 0;     //we count them so we can make sure they are actually null eventually
                    for (int i = 0; i < maxPassages; i++)
                    {
                        if (i < minPassages || Random.value < passageChance)
                        {   //generates a passage if we are below the minimum number of passages OR if the chances are good
                            code = UniquePassage(localOfferNumber, 0, maxAttempts);
                            if (code != null)
                            {   //if the code is unique and good (not null) we save the passage in the passages array
                                PassageFromCode(code);
                                localOfferNumber++;
                            }
                            else
                            {   //if the code is null it means we did not get a unique code in the maxAttempts, so we make it null
                                nullLocalOffers++;
                            }
                        }
                        else
                        {
                            nullLocalOffers++;
                        }
                    }
                    if (portIndex == 6 || portIndex == 20)
                    {   //if we are in Oasis or Happy Bay, we don't want no local offers
                        localOfferNumber = 0;
                    }
                    for (int i = 0; i < 5 - localOfferNumber; i++)
                    {   //make sure the empty offers are actually null (and not just zeroes, which work in the ui...)
                        passages[4 - i] = null;
                    }
                }
                modDataManager.SavePassagesData(passageCodes);
                generatedPassages = true;
            }
            else
            {   //we already have some passages generated, check if they are expired
                if (passages[0] != null && passages[0].expirationDay < GameState.day)
                {   //local passages have expired, refresh them.
                    ResetPassages(true);
                    RefreshPassages(false, true);
                }
                else if ((passages[5] != null && passages[5].expirationDay < GameState.day) && isMajor)
                {
                    ResetPassages(false);
                    RefreshPassages(true, false);
                }
                modDataManager.SavePassagesData(passageCodes);
            }
            selectedPassage = 0;
            localOffers = true;
            if (portIndex == 6 || portIndex == 20)
            {
                selectedPassage = 5;
                localOffers = false;
            }
            RefreshText();
            RefreshOffersButton();
        }
        private static string UniquePassage(int offerNumber, int isGlobal, int maxAttempts)
        {   //make sure you don't get the same passage (code) multiple times
            for (int i = 0; i < maxAttempts; i++)
            {
                string code = GeneratePassage(offerNumber, isGlobal);
                string truncatedCode = code.Split('e')[1];
                //Debug.LogWarning($"PassageDude: UniquePassage: {code}, truncated: {truncatedCode}");
                if (!truncatedCodes.Contains(truncatedCode))
                {
                    passageCodes[offerNumber] = code;
                    truncatedCodes[offerNumber] = truncatedCode;
                    return code;
                }
            }
            return null;
        }
        private static string GeneratePassage(int offerNumber, int isGlobal)
        {   //returns a valid passage code for local passages (if !global) or world passages (if global)

            //OFFER NUMBER
            string code = $"{offerNumber}#";
            //EXPIRATION DAY
            code += $"{GenerateExpirationDate(isGlobal)}e";
            //ORIGIN PORT
            code += $"{portIndex}o";
            //DESTINATION
            int region = GetRegion(portIndex);
            int destinationIndex = 0;
            //local passages arrays
            int[] alAnkh = { 0, 1, 2, 3, 4, 5, 6 };
            float[] aaWeights = { 1.5f, 0.8f, 0.8f, 0.4f, 0f, 0f, 0f }; //no chance to go to Alchemist, Academy and Oasis
            int[] emerald = { 9, 10, 11, 12, 13, 14 };
            float[] eWeights = { 1.5f, 0f, 0.6f, 0.6f, 0.6f, 0f }; //no chance to go to Sanctuary and Serpent Isle
            int[] aestrin = { 15, 16, 17, 18, 19, 20 };
            float[] aeWeights = { 1.5f, 0.2f, 0.6f, 0.6f, 0.6f, 0f }; //no chance to go to Happy Bay
            int[] lagoon = { 22, 23, 24, 25 };
            float[] lWeights = { 0.8f, 1f, 0f, 0f };    //no chance of going to Sen'na and On'na
            //global passages array:
            int[] global = { 0, 9, 15, 23, 6, 20 }; //GRC, DC, FA, FFT, Oasis, HB
            float[] grcWeights = { 0f, 1f, 1f, 0.5f, 1f, 0.3f };
            float[] dcWeights = { 1f, 0f, 1f, 1f, 0.1f, 0.8f };
            float[] faWeights = { 1f, 1f, 0f, 0f, 0.3f, 0.8f };
            float[] fftWeights = { 0.7f, 1f, 0f, 0f, 0f, 0f };
            float[] oasisWeights = { 1f, 0.5f, 0.6f, 0f, 0f, 0.6f };
            float[] hbWeights = { 0.2f, 1f, 1f, 0f, 0.1f, 0f };

            if (isGlobal == 1)
            {   //use global weights and array
                if (portIndex == 0) //GRC
                {
                    destinationIndex = GenerateDestination(global, grcWeights);
                }
                else if (portIndex == 9)    //DC
                {
                    destinationIndex = GenerateDestination(global, dcWeights);
                }
                else if (portIndex == 15)    //FA
                {
                    destinationIndex = GenerateDestination(global, faWeights);
                }
                else if (portIndex == 23)    //FFT
                {
                    destinationIndex = GenerateDestination(global, fftWeights);
                }
                else if (portIndex == 6)    //Oasis
                {
                    destinationIndex = GenerateDestination(global, oasisWeights);
                }
                else if (portIndex == 20)    //HB
                {
                    destinationIndex = GenerateDestination(global, hbWeights);
                }
            }
            else
            {   //use local weights and arrays
                if (region == 0)
                {
                    if (portIndex == 6)
                    {
                        float[] oasisLocalWeights = { 1f, 0.2f, 0.2f, 0.1f, 0f, 0f, 0f };
                        destinationIndex = GenerateDestination(alAnkh, oasisLocalWeights);
                    }
                    else
                    {
                        destinationIndex = GenerateDestination(alAnkh, aaWeights);
                    }
                }
                else if (region == 1)
                {
                    destinationIndex = GenerateDestination(emerald, eWeights);
                }
                else if (region == 2)
                {
                    if (portIndex == 20)
                    {
                        float[] hbLocalWeights = { 1f, 0.1f, 0.2f, 0.2f, 0.1f, 0f };
                        destinationIndex = GenerateDestination(aestrin, hbLocalWeights);
                    }
                    else
                    {
                        destinationIndex = GenerateDestination(aestrin, aeWeights);
                    }
                }
                else
                {
                    destinationIndex = GenerateDestination(lagoon, lWeights);
                }
            }
            code += $"{destinationIndex}d";
            //BOAT
            int boatIndex = GenerateBoat(isGlobal); //note, if isGlobal is 1 it means we are trying to generate a global passage
            code += $"{boatIndex}b";
            //LOCAL / GLOBAL
            code += $"{isGlobal}g";
            //Debug.LogWarning($"PassageDude: Generated code is: {code}");
            return code;
        }
        private static void PassageFromCode(string passageCode)
        {   //transform a passage code string into a FerryPassage passage with all the informations.
            //A passage is defined by:
            //OfferNumber | Expiration Day | Origin port | Destination | Distance | Time | Risk | Boat | Cost

            //PASSAGE CODE EXPLANATION:
            //it's a string created like this: 
            //offerNumber + "#" + expirationDay + "e" + portIndex + "o" + destinationIndex + "d" + boatIndex + "b" + isGlobal + "g"
            //this way we can easily access any passage and get all informations,
            //we can also check that we don't generate two passages that are identical...
            //CODE EXAMPLE: 1# 4e 0o 3d 1b 0g (Second offer in the list, expires on day 4, GRC to Albacore, Sanbuq, not global)

            if (passageCode == "" || passageCode == null)
            {
                Debug.LogError("PassageDude: SavePassageFromCode was given an empty or null code, aborting...");
                return;
            }

            // Parse the code to get the needed values...
            string[] parts = passageCode.Split(new char[] { '#', 'e', 'o', 'd', 'b', 'g' }, StringSplitOptions.RemoveEmptyEntries);
            
            int offerNumber = int.Parse(parts[0]);
            int expirationDay = int.Parse(parts[1]);
            int destinationIndex = int.Parse(parts[3]);
            int boatIndex = int.Parse(parts[4]);
            int isGlobal = int.Parse(parts[5]);
            int region = GetRegion(portIndex);
            int destinationRegion = GetRegion(destinationIndex);

            //DISTANCE 
            int distance = Mathf.RoundToInt(Mission.GetDistance(Port.ports[portIndex], Port.ports[destinationIndex]));
            
            // SPEED
            int[] minSpeed = { 4, 6, 5, 7, 3, 5 };  //represent minimum speed of each boat, with the order being dhow, sanbuq, kakam, junk, cog, brig
            int[] maxSpeed = { 7, 9, 8, 10, 6, 8 }; //represent maximum speed of each boat
            //We can use the boatIndex to reference the minSpeed and maxSpeed of the selected boat

            // TIME
            float minTime = distance / (maxSpeed[boatIndex] / 1.555f);
            float maxTime = distance / (minSpeed[boatIndex] / 1.555f);
            //account for tacking when travelling against trade wind:
            //the correct loop: Al Ankh → Aestrin → Emerald → Al Ankh or FFL (also FFL → Al Ankh)
            // region indexes: AA: 0, EA: 1, AE: 2, FFL: 3
            if (region != destinationRegion)
            {   //passage goes to another region
                if ((region == 0 && destinationRegion != 2) || (region == 1 && (destinationRegion != 0 || destinationRegion != 3)) || (region == 2 && (destinationRegion != 1 || destinationRegion != 3)) || (region == 3 && (destinationRegion != 0 || destinationRegion != 1)))
                {   //if we are against the trade winds, add 10% to minTime and 20% to maxTime
                    minTime *= 1.05f;
                    maxTime *= 1.1f;
                }
            }

            //RISK
            //Depends on the boat (boatIndex and array of fixed risks), region (region and array of risks) 
            //depends on distance as well!
            float[] boatRisk = { 0.3f, 0.1f, 0.4f, 0.15f, 0.20f, 0.05f }; //dhow, sanbuq, kakam, junk, cog, brig
            float[] regionRisk = { 0.1f, 0.2f, 0.15f, 0.25f }; //aa, em, ae, ffl
            float averageRegionRisk = (regionRisk[region] + regionRisk[destinationRegion]) / 2f;

            float distanceRisk = distance / 3000f; ;  //the base risk
            float totalRisk = boatRisk[boatIndex] + averageRegionRisk + distanceRisk;

            //COST
            //Depends on boat and distance
            int[] boatMultiplier = { 15, 40, 20, 50, 10, 60 };  //dhow, sanbuq, kakam, junk, cog, brig
            float costMultiplier;
            if (isGlobal == 1)
            {
                costMultiplier = Mathf.Abs(PassageDudeMain.worldPriceMultiplierConfig.Value);
            }
            else
            {
                costMultiplier = Mathf.Abs(PassageDudeMain.localPriceMultiplierConfig.Value);
            }
            float fluctuation = 1f + Random.Range(-0.2f, 0.2f); //fluctuate the price between -20% to +20% of the original value
            int cost = Mathf.RoundToInt(distance * boatMultiplier[boatIndex] * GetExchangeRate(region) * costMultiplier * fluctuation);
            
            
            //PASSAGE CODE:
            string code = offerNumber + "#" + expirationDay + "e" + portIndex + "o" + destinationIndex + "d" + boatIndex + "b" + isGlobal + "g"; //unique identifier for a passage, to be used to avoid getting the same passage twice or to load the same passage.
            
            //Assign all the values to the correct passage offer:
            passages[offerNumber].offerNumber = offerNumber;
            passages[offerNumber].passageCode = code;
            passages[offerNumber].originPort = portIndex;
            passages[offerNumber].destinationIndex = destinationIndex;
            passages[offerNumber].boat = boatIndex;
            passages[offerNumber].distance = distance;
            passages[offerNumber].risk = totalRisk;
            passages[offerNumber].cost = cost;
            passages[offerNumber].minTime = minTime;
            passages[offerNumber].maxTime = maxTime;
            passages[offerNumber].isGlobal = isGlobal;
            passages[offerNumber].expirationDay = expirationDay;
        }
        private static int GenerateExpirationDate(int isGlobal)
        {   //generates an expiration date for a passage
            if (isGlobal == 1)
            {   //global passages expire 1 to 4 days after being generated the first time
                
                return GameState.day + 2;
            }
            else
            {   //local passages expire 0 to 2 after being generated the first time
                return GameState.day + 1;
            }
        }
        private static void ResetPassages(bool onlyLocal)
        {   //makes local passages null if onlyLocal is true, else it makes ONLY global passages null
            if (onlyLocal)
            {   //only reset local passages
                for (int i = 0; i < 5; i++)
                {
                    truncatedCodes[i] = "";
                    passageCodes[i] = "";
                    passages[i] = new FerryPassage();
                }
            }
            else
            {   //only resets global passages
                for (int i = 5; i < 10; i++)
                {
                    truncatedCodes[i] = "";
                    passageCodes[i] = "";
                    passages[i] = new FerryPassage();
                }
            }
            generatedPassages = false;
        }
        private static void RefreshPassages(bool noLocal, bool noGlobal)
        {   //refresh available passages after a certain amount of time has passed
            GetAvailablePassages(noLocal, noGlobal);
            RefreshText();
            RefreshOffersButton();
        }
        private static void LoadPassagesData()
        {   //attempts to load passages data into the passages array
            if(modDataManager.HasValidData(portIndex))
            {   //check if there is valid data in the modData dictionary
                passageCodes = modDataManager.LoadPassagesData();
                for (int i = 0; i < passageCodes.Length; i++)
                {   //load the codes in the passages array
                    if (passageCodes[i] != "")
                    {   //assigns all the values to the passages that are not null
                        if (int.Parse(passageCodes[i].Split('#', 'e', 'o')[2]) == portIndex)
                        {   //if the og port is the current port, load it, else nullify it.
                            PassageFromCode(passageCodes[i]);
                        }
                        else
                        {
                            //Debug.LogWarning("PassageDude: nullified a code");
                            passages[i] = null;
                        }
                    }
                    else
                    {   //make sure the empty offers are null passages
                        passages[i] = null;
                    }
                }
                //Debug.LogWarning("PassageDude: Loaded passageCodes from save...");
                generatedPassages = true;
            }
            else
            {
                //Debug.LogError("PassageDude: no valid data to load");
                return;
            }
        }
        
        //UI MANAGEMENT
        public static void OpenLargeUI()
        {   //opens the largeUI
            FerryIndexToPortIndex();
            MouseLook.ToggleMouseLookAndCursor(newState: false);    //Enables using the mouse
            Refs.SetPlayerControl(state: false);    //Disables the player moving
            if (largeUI != null)
            {
                largeUI.SetActive(true);    //Enables the ui gameObject
            }
            else
            {
                Debug.LogError("PassageDude: largeUI is null!");
            }
            PositionUI();   //positions the ui in front of the player
            if (isMajor)
            {   //in GRC, DC, FA, FFT, Oasis, HB we allow global passages and more passages
                GetAvailablePassages(false, false);
            }
            else
            {   //only localPassages
                GetAvailablePassages(false, true);
            }
            //By deafault open the UI with the first local passage selected
            localOffers = true;
            selectedPassage = 0;
            if (portIndex == 6 || portIndex == 20)
            {
                selectedPassage = 5;
                localOffers = false;
            }
            DrawOnMap();
            UISoundPlayer.instance.PlayOpenSound();
        }
        public static void CloseLargeUI()
        {   //closes the LargeUI
            largeUI.SetActive(false);
            MouseLook.ToggleMouseLookAndCursor(newState: true); //Disables the mouse
            Refs.SetPlayerControl(state: true); //re-enables the player moving
            UISoundPlayer.instance.PlayCloseSound();
        }
        private static void PositionUI()
        {   //positions the largeUI correctly compared to the player

            Vector3 playerForward = player.transform.forward; //forward direction of the player
            float distance = 0.02f; //distance of the largeUI from the player
            Vector3 targetPosition = player.position + playerForward * distance; //the position we want the largeUI to appear
            largeUI.transform.position = targetPosition;
            largeUI.transform.parent = player;  //so that the ui moves with the player when crouching (wtf?!)
            largeUI.transform.LookAt(player);   //make it so the largeUI always faces the player
            largeUI.transform.Translate(0f, -0.425f, 0f); //move the ui up a bit (it's the z axis because the ui is rotated...)
        }   
        private static void InitialiseText()
        {   //initialises the textMeshes, assigning the correct textMeshes to the public textMeshes in the class...
            allText = largeUI.GetComponentsInChildren<TextMesh>();
            //origin port
            originPort = allText[2];
            //destinationPort
            destinationPort = allText[4];
            //Cost, time, risk
            cost = allText[6];
            time = allText[7];
            risk = allText[8];
            //distance
            distance = allText[10];
            //current passage name
            passageName = allText[11];
            //not enough money warning
            notEnough = allText[12];
            //passage options
            passage0text = allText[13];
            passage1text = allText[14];
            passage2text = allText[15];
            passage3text = allText[16];
            passage4text = allText[17];
            //port name (current island)
            portName = allText[21];
            approximateLocation = allText[23]; //should be the Approximate Location text
            noGlobalPassages = allText[24]; //Tell the player they should travel to a major port for global passages
        }
        public static void RefreshText()
        {   //refreshes all the text in the UI
            //origin port
            originPort.text = Port.ports[portIndex].GetPortName();
            //destinationPort
            destinationPort.text = Port.ports[passages[selectedPassage].destinationIndex].GetPortName();
            //Cost, time, risk
            cost.text = $"{passages[selectedPassage].cost}";
            time.text = $"{GetTime(Mathf.RoundToInt(passages[selectedPassage].minTime))} /\n{GetTime(Mathf.RoundToInt(passages[selectedPassage].maxTime))}";
            risk.text = $"{Mathf.Round(passages[selectedPassage].risk * 100)}%";
            //distance
            distance.text = $"{passages[selectedPassage].distance} miles";
            //current passage name
            passageName.text = $"{GetBoatFromIndex(passages[selectedPassage].boat)} to {Port.ports[passages[selectedPassage].destinationIndex].GetPortName()}";
            //not enough money warning
            if (PlayerGold.currency[GetLocalCurrency(GetRegion(portIndex))] < passages[selectedPassage].cost)
            {
                notEnough.text = "You don't have enough money!\nLocal currency only!";
            }
            else
            {
                notEnough.text = "";  //hidden by default, show only if necessary
            }
            //passage options
            if (localOffers)
            {
                if(portIndex == 6 || portIndex == 20)
                {                               
                    noGlobalPassages.text = "No passages to other minor islands\nin the archipelago are available\nhere. You should travel to a capital\nfirst...";
                }
                else
                {
                    noGlobalPassages.text = ""; //never display this message in local offers
                }
                if (passages[0] == null)
                {
                    passage0text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage0text.transform.parent.gameObject.SetActive(true);
                    passage0text.text = $"{GetBoatFromIndex(passages[0].boat)} to {Port.ports[passages[0].destinationIndex].GetPortName()}";
                }
                if (passages[1] == null)
                {
                    passage1text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage1text.transform.parent.gameObject.SetActive(true);
                    passage1text.text = $"{GetBoatFromIndex(passages[1].boat)} to {Port.ports[passages[1].destinationIndex].GetPortName()}";
                }
                if (passages[2] == null)
                {
                    passage2text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage2text.transform.parent.gameObject.SetActive(true);
                    passage2text.text = $"{GetBoatFromIndex(passages[2].boat)} to {Port.ports[passages[2].destinationIndex].GetPortName()}";
                }
                if (passages[3] == null)
                {
                    passage3text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage3text.transform.parent.gameObject.SetActive(true);
                    passage3text.text = $"{GetBoatFromIndex(passages[3].boat)} to {Port.ports[passages[3].destinationIndex].GetPortName()}";
                }
                if (passages[4] == null)
                {
                    passage4text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage4text.transform.parent.gameObject.SetActive(true);
                    passage4text.text = $"{GetBoatFromIndex(passages[4].boat)} to {Port.ports[passages[4].destinationIndex].GetPortName()}";
                }
            }
            else
            {
                if (!isMajor)
                {   //this message should only be displayed in non-Major ports when world offers are selected
                    noGlobalPassages.text = "No passages to other archipelagos\nare available here. You should travel\nto a major port first...";
                }
                else
                {   //hide it if it's a major port
                    noGlobalPassages.text = "";
                }
                if (passages[5] == null)
                {
                    passage0text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage0text.transform.parent.gameObject.SetActive(true);
                    passage0text.text = $"{GetBoatFromIndex(passages[5].boat)} to {Port.ports[passages[5].destinationIndex].GetPortName()}";
                }
                if (passages[6] == null)
                {
                    passage1text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage1text.transform.parent.gameObject.SetActive(true);
                    passage1text.text = $"{GetBoatFromIndex(passages[6].boat)} to {Port.ports[passages[6].destinationIndex].GetPortName()}";
                }
                if (passages[7] == null)
                {
                    passage2text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage2text.transform.parent.gameObject.SetActive(true);
                    passage2text.text = $"{GetBoatFromIndex(passages[7].boat)} to {Port.ports[passages[7].destinationIndex].GetPortName()}";
                }
                if (passages[8] == null)
                {
                    passage3text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage3text.transform.parent.gameObject.SetActive(true);
                    passage3text.text = $"{GetBoatFromIndex(passages[8].boat)} to {Port.ports[passages[8].destinationIndex].GetPortName()}";
                }
                if (passages[9] == null)
                {
                    passage4text.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    passage4text.transform.parent.gameObject.SetActive(true);
                    passage4text.text = $"{GetBoatFromIndex(passages[9].boat)} to {Port.ports[passages[9].destinationIndex].GetPortName()}";
                }
            }
            //port name (current island)
            portName.text = Port.ports[portIndex].GetPortName();
            //approximate location
            if ((GetRegion(portIndex) != 3 && (passages[selectedPassage].destinationIndex == 23)) || (GetRegion(portIndex) == 3 && GetRegion(passages[selectedPassage].destinationIndex) != 3))
            {   //if the destination is FFT and we are not in FFL, we use the approximate location instead of the map
                approximateLocation.text = "Map unavailable,\ntrust the captain!";
                DrawMap.mapRenderer.gameObject.SetActive(false);
            }
            else
            {
                approximateLocation.text = "";
                DrawMap.mapRenderer.gameObject.SetActive(true);
            }
            //Update the target destination for the Buy Passage button.
            LargeUIBuyPassageButton.instance.destination = Port.ports[passages[selectedPassage].destinationIndex];
            LargeUIBuyPassageButton.instance.maxTime = passages[selectedPassage].maxTime;
            LargeUIBuyPassageButton.instance.minTime = passages[selectedPassage].minTime;
            LargeUIBuyPassageButton.instance.risk = passages[selectedPassage].risk;
            LargeUIBuyPassageButton.instance.cost = passages[selectedPassage].cost;
            LargeUIBuyPassageButton.instance.currency = GetLocalCurrency(GetRegion(portIndex));
        }
        public static void AddButtonComponents()
        {   //applies the correct component to the correct button
            //CLOSE BUTTON
            largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(0).GetChild(0).gameObject.AddComponent<LargeUICloseButton>();
            //LOCAL BUTTON
            largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(2).GetChild(0).gameObject.AddComponent<LargeUILocalButton>();
            //WORLD BUTTON
            largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(1).GetChild(0).gameObject.AddComponent<LargeUIWorldButton>();
            //OFFERS BUTTONS
            largeUI.transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).gameObject.AddComponent<LargeUIPassageButton>();
            largeUI.transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).gameObject.AddComponent<LargeUIPassageButton>();
            largeUI.transform.GetChild(0).GetChild(1).GetChild(2).GetChild(0).gameObject.AddComponent<LargeUIPassageButton>();
            largeUI.transform.GetChild(0).GetChild(1).GetChild(3).GetChild(0).gameObject.AddComponent<LargeUIPassageButton>();
            largeUI.transform.GetChild(0).GetChild(1).GetChild(4).GetChild(0).gameObject.AddComponent<LargeUIPassageButton>();
            if (localOffers)
            {
                largeUI.transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 0;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 1;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(2).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 2;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(3).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 3;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(4).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 4;
            }
            else
            {
                largeUI.transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 5;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 6;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(2).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 7;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(3).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 8;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(4).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 9;
            }
            activeMat = largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(2).GetChild(0).GetComponent<Renderer>().material;
            inactiveMat = largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(1).GetChild(0).GetComponent<Renderer>().material;
            //MAP BUTTON
            largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).gameObject.AddComponent<LargeUIMapButton>();
            mapPos = largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).localPosition;
            largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).gameObject.AddComponent<DrawMap>();
            DrawMap.routeLine = largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).GetChild(6).gameObject.GetComponent<LineRenderer>();
            DrawMap.routeLine.material.renderQueue = 3001;
            DrawMap.destinationMarker = largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).GetChild(7).gameObject.GetComponent<Transform>();
            DrawMap.destinationMarker.gameObject.GetComponent<Renderer>().material.renderQueue = 3001;
            DrawMap.mapRenderer = largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).gameObject.GetComponent<Renderer>();
            DrawMap.oceanMap = PassageDudeMain.oceanMap;
            DrawMap.alAnkhMap = PassageDudeMain.alAnkhMap;
            DrawMap.emeraldMap = PassageDudeMain.emeraldMap;
            DrawMap.aestrinMap = PassageDudeMain.aestrinMap;
            DrawMap.lagoonMap = PassageDudeMain.lagoonMap;
            //BUY PASSAGE BUTTON
            largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(0).GetChild(0).gameObject.AddComponent<LargeUIBuyPassageButton>();
            //largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(0).GetChild(0).GetComponent<LargeUIBuyPassageButton>().destination = Port.ports[passages[selectedPassage].destinationIndex];
            LargeUIBuyPassageButton.instance.destination = Port.ports[passages[selectedPassage].destinationIndex];
            LargeUIBuyPassageButton.instance.maxTime = passages[selectedPassage].maxTime;
            LargeUIBuyPassageButton.instance.minTime = passages[selectedPassage].minTime;
            LargeUIBuyPassageButton.instance.risk = passages[selectedPassage].risk;
            LargeUIBuyPassageButton.instance.cost = passages[selectedPassage].cost;
        }
        public static void RefreshOffersButton()
        {   //changes the offernumbers associated with the offer buttons from local to world
            //also updates the material of the loacal / world button (shows which one is selected)
            if (localOffers)
            {   //offers buttons
                largeUI.transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 0;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 1;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(2).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 2;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(3).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 3;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(4).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 4;
                //Local/world buttons
                largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(2).GetChild(0).GetComponent<Renderer>().material = activeMat;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(1).GetChild(0).GetComponent<Renderer>().material = inactiveMat;
            }
            else
            {   //offers buttons
                largeUI.transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 5;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 6;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(2).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 7;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(3).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 8;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(4).GetChild(0).GetComponent<LargeUIPassageButton>().offerNumber = 9;
                //Local/world buttons
                largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(2).GetChild(0).GetComponent<Renderer>().material = inactiveMat;
                largeUI.transform.GetChild(0).GetChild(1).GetChild(5).GetChild(1).GetChild(0).GetComponent<Renderer>().material = activeMat;
            }
        }
        public static void ZoomMap(bool zoomed)
        {   //controls the zoom on the map. If it's already zoomed, zoom back, if not, zoom in.
            if (!zoomed)
            {   //zoom in
                largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).localPosition = mapZoomedPos;
                largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).gameObject.GetComponent<Renderer>().material.renderQueue = 3001;
            }
            else
            {   //zoom back
                largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).localPosition = mapPos;
                largeUI.transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).gameObject.GetComponent<Renderer>().material.renderQueue = 2450;
            }
            
        }
        public static void DrawOnMap()
        {   //updates the drawings on the map (lines connecting ports) and the map used
            bool useOceanMap = false;
            if (passages[selectedPassage].isGlobal == 1 || portIndex == 6 || portIndex == 20)
            {   //note we using the ocean map
                useOceanMap = true;
            }
            if (useOceanMap)
            {   //using the ocean map
                if (passages[selectedPassage].destinationIndex == 23 || GetRegion(portIndex) == 3)
                {   //going to or departing from fft, don't need to draw anything...
                    return;
                }
                SetMapTexture(DrawMap.oceanMap);
                DrawMap.routeLine.SetPosition(0, Port.ports[portIndex].oceanMapLocation.localPosition);
                DrawMap.routeLine.SetPosition(1, Port.ports[passages[selectedPassage].destinationIndex].oceanMapLocation.localPosition);
                DrawMap.destinationMarker.localPosition = Port.ports[passages[selectedPassage].destinationIndex].oceanMapLocation.localPosition;
            }
            else
            {
                if (GetRegion(portIndex) == 0)
                {   //alAnkh
                    SetMapTexture(DrawMap.alAnkhMap);
                }
                else if (GetRegion(portIndex) == 1)
                {   //emerald
                    SetMapTexture(DrawMap.emeraldMap);
                }
                else if (GetRegion(portIndex) == 2)
                {   //aestrin
                    SetMapTexture(DrawMap.aestrinMap);
                }
                else if (GetRegion(portIndex) == 3)
                {   //ffl
                    SetMapTexture(DrawMap.lagoonMap);
                }
                DrawMap.routeLine.SetPosition(0, Port.ports[portIndex].localMapLocation.localPosition);
                DrawMap.routeLine.SetPosition(1, Port.ports[passages[selectedPassage].destinationIndex].localMapLocation.localPosition);
                DrawMap.destinationMarker.localPosition = Port.ports[passages[selectedPassage].destinationIndex].localMapLocation.localPosition;
            }
        }
        private static void SetMapTexture(Texture tex)
        {
            DrawMap.mapRenderer.material.SetTexture("_EmissionMap", tex);
            DrawMap.mapRenderer.material.SetTexture("_MainTex", tex);
        }

        //UTILIES METHODS
        private static void FerryIndexToPortIndex()
        {   //associate the passageIndex to the correct port index (so we can use the Port.ports array to get names and stuff like that)
            switch (passageIndex)
            {   //Al'Ankh
                case 1: portIndex = 0; break; //Gold Rock City
                case 2: portIndex = 1; break; //Al'Nilem
                case 3: portIndex = 2; break; //Neverdin
                case 4: portIndex = 3; break; //Albacore
                case 7: portIndex = 4; break; //Alchemist (No dude)
                case 8: portIndex = 5; break; //Academy (No dude)
                case 20: portIndex = 6; break;  //Oasis
                //Emerald
                case 9: portIndex = 9; break; //Dragon Cliff
                case 10: portIndex = 10; break; //Sanctuary (No dude)
                case 11: portIndex = 11; break; //Crab Beach
                case 12: portIndex = 12; break; //New Port
                case 13: portIndex = 13; break; //Sage Hills
                case 22: portIndex = 14; break; //Serpent Isle
                //Aestrin
                case 15: portIndex = 15; break; //Fort Aestrin
                case 16: portIndex = 16; break; //Sunspire
                case 17: portIndex = 17; break; //Mt. Malefic
                case 18: portIndex = 20; break; //Happy Bay
                case 19: portIndex = 19; break; //Eastwind
                case 21: portIndex = 18; break; //Siren Song
                //Fire Fish Lagoon
                case 26: portIndex = 23; break; //Fire Fish Town
                case 27: portIndex = 22; break; //Kicia Bay
                case 28: portIndex = 25; break; //Sen'na (No dude)
                case 29: portIndex = 24; break; //On'na (No dude)
            }
        }
        private static int GetRegion(int portIndex)
        {   //returns a number 0 - 3 representing the region of a port (from port index)
            if (portIndex >= 0 && portIndex <= 6)
            {
                return 0;   //Al'Ankh
            }
            else if (portIndex >= 9 && portIndex <= 14)
            {
                return 1;   //Emerald
            }
            else if (portIndex >=15 && portIndex <= 20)
            {
                return 2; //Aestrin
            }
            else if (portIndex >= 22)
            {
                return 3;   //FFL
            }
            else
            {
                return 0;
            }
        }
        private static int GenerateDestination(int[] ports, float[]weights)
        {   //parameters are an array of ports indexes (all ports in a specific region) and an array of weights (0 means never going there, 1 means it's very likely to go there)
            // Filter out the cantPick value and corresponding weight
            var eligibleValues = ports.Where((value, index) => value != portIndex).ToArray();
            var eligibleWeights = weights.Where((weight, index) => ports[index] != portIndex).ToArray();

            // Normalize weights
            float totalWeight = eligibleWeights.Sum();
            float[] normalizedWeights = eligibleWeights.Select(weight => weight / totalWeight).ToArray();

            // Weighted random selection
            float randomValue = Random.value;
            float cumulativeWeight = 0f;

            for (int i = 0; i < eligibleValues.Length; i++)
            {
                cumulativeWeight += normalizedWeights[i];
                if (randomValue < cumulativeWeight)
                {
                    return eligibleValues[i];
                }
            }

            // Fallback in case of rounding errors
            return eligibleValues.Last();
        }
        private static int GenerateBoat(int isGlobal)
        {   //BOAT SELECTION
            int region = GetRegion(portIndex);
            float rnd = Random.value;
            float bigBoatThreshold = 0.8f;
            if (isGlobal == 1)
            {   //always use big boats for global passages
                if (rnd <= 0.33f)
                {
                    return 1;  //sanbuq
                }
                else if (rnd <= 0.66f)
                {
                    return 3;  //junk
                }
                else
                {
                    return 5;  //brig
                }
            }
            if (portIndex == 0 || portIndex == 9 || portIndex == 15 || portIndex == 23 || portIndex == 6 || portIndex == 20)
            {   //use larger boats more often
                bigBoatThreshold = 0.6f;
            }
            if (rnd > bigBoatThreshold)
            {   //big boats
                if (region == 0)    //AA
                {
                    return 1;  //sanbuq
                }
                else if (region == 1 || region == 3) //EA and FFL
                {
                    return 3;  //junk
                }
                else    //Aestrin
                {
                    return 5;  //brig
                }
            }
            else
            {   //small boats
                if (region == 0)    //AA
                {
                    return 0;  //dhow
                }
                else if (region == 1 || region == 3) //EA and FFL
                {
                    return 2;  //kakam
                }
                else    //Aestrin
                {
                    return 4;  //cog
                }
            }
        }
        private static string GetBoatFromIndex(int boatIndex)
        {   //returns a string containing the boat name
            string[] boats = { "Dhow", "Sanbuq", "Kakam", "Junk", "Cog", "Brig" };
            return boats[boatIndex];
        }
        private static int GetLocalCurrency(int region)
        {   //returns the correct currency index for a given region
            int[] currency = { 0, 1, 2, 1 };    //AlAnkh lions, Emerald Dragons, Aestrin Crowns, Emerald Dragons (for FFL)

            return currency[region];
        }
        private static string GetTime(int hours)
        {   //goes from hours to days and hours
            int days = hours / 24;
            int hoursLeft = hours % 24;
            
            if (days > 0)
            {
                if (hoursLeft > 0)
                {
                    return $"{days} days, {hoursLeft} hours";
                }
                else
                {
                    return $"{days} days";
                }
            }
            else
            {
                return $"{hoursLeft} hours";
            }
        }
        private static float GetExchangeRate(int region)
        {   //Converts prices from AAL to local currency
            //default prices are in Al Ankh Lions
            int currency = GetLocalCurrency(region); //identifies the local currency
            if (currency == 0)
            {
                return 1f;
            }
            else
            {
                return CurrencyMarket.instance.GetExchangeRate(0, currency, false);
            }
        }
    }
    public class FerryPassage
    {   //contains all the informations about a specific passage and everything needed to generate one.
        public int offerNumber;
        public string passageCode;
        public int originPort;
        public int destinationIndex;
        public int boat;
        public int distance;
        public float risk;
        public int cost;
        public float minTime;
        public float maxTime;
        public int isGlobal;
        public int expirationDay;   //day after which the passage won't be available anymore
    }
    public class DrawMap : MonoBehaviour
    {   //stores the textures used by the map and the renderer for the route line and marker
        //TEXTURES
        public static Texture oceanMap;
        public static Texture alAnkhMap;
        public static Texture emeraldMap;
        public static Texture aestrinMap;
        public static Texture lagoonMap;
        //OTHER
        public static Renderer mapRenderer;
        public static LineRenderer routeLine;
        public static Transform destinationMarker;
    }
    public class ModDataManager
    {
        private string modName;
        private const char delimiter = ';';

        public ModDataManager(string modName)
        {
            this.modName = modName;
        }
        public void SavePassagesData(string[] codes)
        {   //saves the array as csv to the modData dictionary, using the mod GUID as key
            string delimitedString = string.Join(delimiter.ToString(), codes);
            GameState.modData[modName] = delimitedString;
        }
        public string[] LoadPassagesData()
        {   //loads the data from the modData dictionary, make sure to use this only after a HasValidData check...
            if (GameState.modData.TryGetValue(modName, out string delimitedString))
            {
                return delimitedString.Split(delimiter);
            }
            else
            {
                Debug.LogError("PassageDude: returning null from ModDataManager.LoadPassageData()");
                return null;
            }
        }
        public bool HasValidData(int portIndex)
        {   //check if there is data saved and if it is valid for the current port
            if(GameState.modData.ContainsKey(modName))
            {   //there is a modName entry in the dictionary
                GameState.modData.TryGetValue(modName, out string delimitedString);
                string[] codes = delimitedString.Split(delimiter);
                if (codes.Length > 0)
                {   //array not empty, there is data saved!
                    if (codes[0].Contains("#"))
                    {   //first entry is a valid code (probably)
                        if (int.Parse(codes[0].Split('#', 'e', 'o')[2]) == portIndex)
                        {   //code is valid for the current port
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
    public class FerryTravel : MonoBehaviour
    {   //controls the travel part of the mod
        public Port destination;
        public float maxTime;
        public float minTime;
        public float risk;
        public int cost;
        public int currency;


        public static FerryTravel instance;
        private readonly int msToWait = 1000;    //set this to the amount of millisecond to wait. It's actually not milliseconds... probably because it runs slower?
        private readonly int fadeTime = 200;

        //MONOBEHAVIOR SPECIAL METHODS
        private void Awake()
        {   //assigns the instance of FerryTravel
            instance = this;
        }

        //TRAVEL RELATED METHODS
        public void Travel()
        {   //moves the player to destination, fills needs, pays, advances time, etc...
            
            MouseLook.ToggleMouseLookAndCursor(newState: false);    //these two are restored after time has passed
            Refs.SetPlayerControl(state: false);                    //in the WaitAndFadeOut task
            GameState.recovering = true;                            //needed to have instante world shifting, restored at the end of SpawDude
            PassageDudePatches.justTeleported = true;                 //needed to avoid SpawnDude potentially mess up the Recovery process...
            DestroyUI();
            TeleportPlayer();                                       //move the player to destination
            AdvanceTime(TimeToPass());                              //Set the time to arrival time
            PayForPassage();                                        //removes gold from player
            FillNeeds();                                            //Fill all player needs.
        }
        private void TeleportPlayer()
        {   //moves the player to destination
            //Refs.charController.transform.position = destination.transform.position + Vector3.up * 101f;
            Refs.charController.transform.position = GetDestinationCoordinates(destination);
        }
        private void PayForPassage()
        {   //subtract the cost from the player gold
            PlayerGold.currency[currency] -= cost;
        }
        private void FillNeeds()
        {   //max out all player needs when you travel
            PlayerNeeds.water = 100f;
            PlayerNeeds.food = 100f;
            PlayerNeeds.foodDebt = 100f;
            PlayerNeeds.sleepDebt = 100f;
            PlayerNeeds.sleep = 100f;
        }
        private void AdvanceTime(float timeToPass)
        {   //advances the time to the desired moment
            //WARP VARIABLES
            float arrivalTime = Sun.sun.globalTime + timeToPass;    //Time we need to stop the warping at
            int daysToPass = (int)arrivalTime / 24;                 //Days we have to pass (midnights)
            float arrivalHour = arrivalTime % 24f;                  //The hour of the last day we need to stop warping

            _ = WaitAndFadeOut(msToWait);

            //PASS DAYS
            for (int i = 0; i < daysToPass; i++)
            {
                GameState.day++;
                DayLogs.instance.NewDaySheets();
            }

            //PASS HOURS
            Sun.sun.globalTime = arrivalHour;
        }

        //UTILITIES
        private string LoadingBar(float currentValue, float finalValue)
        {   //creates a classic loading bar using ASCII characters
            int barLength = 1000; // Total length of the loading bar
            int filledLength = (int)(currentValue * barLength / finalValue);
            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < barLength; i++)
            {
                if (i < filledLength)
                {
                    bar.Append("█"); // Filled character
                }
                else
                {
                    bar.Append("░"); // Empty character
                }
            }
            return $"<size=1%><color=orange>{bar}</color></size>";
        }
        private float TimeToPass()
        {   //calculates the arrival time, 
            float lerpParameter = 0.5f;
            if (Random.value < risk)
            {   //move toward more time by an amount proportionate to the risk
                lerpParameter = Mathf.Lerp(lerpParameter, 1f, risk);
                if (Random.value < risk / 10f)
                {   //extra bad luck, time set to maximum
                    return maxTime;
                }
            }
            else
            {   //move toward less time by an amount proportionate to risk
                lerpParameter = Mathf.Lerp(0f, lerpParameter, 1f - risk);
                if (Random.value < (1 - risk) / 10f)
                {   //extra good luck, time set to minimum
                    return minTime;
                }
            }
            return Mathf.Lerp(minTime, maxTime, lerpParameter);
        }
        private Vector3 GetDestinationCoordinates(Port destination)
        {   //returns the coordinates we want to teleport to
            //coordinates array contains positions as they are in the editor. We add the current world offset
            //so that we can teleport correctly to those positions.
            Vector3 offset = FloatingOriginManager.instance.outCurrentOffset;
            Vector3[] coordinates =
            {   //AL ANKH
                new Vector3(-43658.69f, 2.54f, -44098.2f),      //0 Gold Rock City
                new Vector3(-49041.69f, 2.24f, -42950.55f),     //1 Al'Nilem
                new Vector3(-48901.4f, 2.32f, -45948.3f),       //2 Neverdin
                new Vector3(-40476.52f, 2.328f, -46683.57f),    //3 Albacore
                new Vector3(0f, 0f, 0f),                        //4 Alchemist   (No dude)
                new Vector3(0f, 0f, 0f),                        //5 Academy     (No dude)
                new Vector3(-45682.41f, 2.27f, -29275.72f),     //6 Oasis
                new Vector3(0f, 0f, 0f),                        //7 Test Port
                new Vector3(0f, 0f, 0f),                        //8 null
                //EMERALD
                new Vector3(42911.99f, 2.263f, -41884.92f),     //9  Dragon Cliff
                new Vector3(0f, 0f, 0f),                        //10 Sanctuary   (No dude)
                new Vector3(43986.49f, 2.71f, -38776.6f),       //11 Crab Beach
                new Vector3(42676.61f, 2.063255f, -35027.15f),  //12 New Port
                new Vector3(40584.6f, 2.26f, -45942.49f),       //13 Sage Hills
                new Vector3(39620.4f, 2.39f, -37914.31f),       //14 Serpent Isle(No dude)
                //AESTRIN
                new Vector3(5707.44f, 3.254f, 38992.54f),       //15 Fort Aestrin
                new Vector3(8423.06f, 2.9f, 37845.23f),         //16 Sunspire
                new Vector3(10462.4f, 2.34f, 35428.92f),        //17 Mount Malefic
                new Vector3(5216.674f, 2.36f, 42785.71f),       //18 Siren Song
                new Vector3(1981.471f, 2.088894f, 44142.91f),   //19 Eastwind
                new Vector3(32231.65f, 4.37f, -5742.877f),      //20 Happy Bay

                new Vector3(0f, 0f, 0f),                        //21 Chronos    (No dude)
                //LAGOON
                new Vector3(26031.74f, 2.508f, -70995.01f),    //22 Kicia Bay
                new Vector3(28401.27f, 2.18f, -70677.51f),    //23 Fire Fish Town
                new Vector3(0f, 0f, 0f),                        //24 On'na      (No dude)
                new Vector3(0f, 0f, 0f),                        //25 Sen'na     (No dude)
            };

            return coordinates[destination.portIndex] + offset; ;
        }
        private void DestroyUI()
        {   //destroys the large and smallui before teleporting the player away
            Destroy(LargeUI.largeUI);
            Destroy(SmallUI.largeUI);
            Destroy(SmallUI.smallUI);
            SmallUI.instantiatedUI = false;
            LargeUI.generatedPassages = false;
        }

        //ASYNC TASKS
        private async Task WaitAndFadeOut(int milliseconds)
        {
            while (milliseconds > 0)
            {
                if (milliseconds == msToWait)
                {
                    Camera.main.GetComponent<OVRScreenFade>().SetFadeLevel(1f);
                }
                await Task.Delay(1);
                Sleep.instance.recoveryText.text = $"<size=40%>Travelling to</size>\n{destination.GetPortName()}\n{LoadingBar(msToWait - milliseconds, msToWait)}";
                milliseconds--;
                if (milliseconds == 0)
                {
                    Sleep.instance.recoveryText.text = "";
                    _ = FadeIn(fadeTime);
                    MouseLook.ToggleMouseLookAndCursor(newState: true);
                    Refs.SetPlayerControl(state: true);
                }
            }

        }
        private async Task FadeIn(int milliseconds)
        {   //fades the screen. 1f = black, 0f = transparent
            float targetAlpha = 0f;
            OVRScreenFade fade = Camera.main.GetComponent<OVRScreenFade>();
            float initialAlpha = fade.currentAlpha;
            if (milliseconds == fadeTime)
            {

            }
            while (milliseconds > 0)
            {
                float fadeLevel = Mathf.Lerp(initialAlpha, targetAlpha, (float)(fadeTime - milliseconds) / 100f);
                await Task.Delay(1);
                fade.SetFadeLevel(fadeLevel);
                milliseconds--;
            }
            if (milliseconds == 0)
            {
                fade.SetFadeLevel(0f);
            }
        }
    }

    //BUTTONS SCRIPTS 
    //Must be added as component to the correct GameObjects
    public class GPButtonBook : GoPointerButton
    {   //attach this as a component to the ferryUI book
        public Transform dudeTransform;

        public override void OnActivate()
        {   //This is what gets called when you click on the book
            SmallUI.ShowSmallUI(dudeTransform);
            ForceUnlook();
        }
    }
    public class SmallUIButton : GoPointerButton
    {   //controls the button on the smallUI, must be added to the smallUI object!
        public override void OnActivate()
        {   //This is what gets called when you click on the book
            SmallUI.HideSmallUI();
            SmallUI.OpenBook();
            ForceUnlook();
        }
    }
    public class LargeUICloseButton : GoPointerButton
    {   //controls the close button in the largeUI
        public override void OnActivate()
        {   //This is what gets called when you click on the book
            LargeUI.CloseLargeUI();
            ForceUnlook();
        }
    }
    public class LargeUILocalButton : GoPointerButton
    {   //controls the Local button in the largeUI
        public override void OnActivate()
        {   //This is what gets called when you click on the button
            LargeUI.localOffers = true;
            UISoundPlayer.instance.PlayUISound(UISounds.buttonClick, 0.5f, 1f);
            LargeUI.RefreshText();
            LargeUI.DrawOnMap();
            LargeUI.RefreshOffersButton();
            ForceUnlook();
        }
    }
    public class LargeUIWorldButton : GoPointerButton
    {   //controls the Local button in the largeUI
        public override void OnActivate()
        {   //This is what gets called when you click on the button
            LargeUI.localOffers = false;
            UISoundPlayer.instance.PlayUISound(UISounds.buttonClick, 0.5f, 1f);
            LargeUI.RefreshText();
            LargeUI.DrawOnMap();
            LargeUI.RefreshOffersButton();
            ForceUnlook();
        }
    }
    public class LargeUIPassageButton : GoPointerButton
    {   //controls the four passages buttons in the largeUI
        public int offerNumber;
        public override void OnActivate()
        {   //This is what gets called when you click on the button
            LargeUI.selectedPassage = offerNumber;
            UISoundPlayer.instance.PlayUISound(UISounds.buttonClick, 0.5f, 1f);
            LargeUI.RefreshText();
            LargeUI.DrawOnMap();
            ForceUnlook();
        }
    }
    public class LargeUIMapButton : GoPointerButton
    {   //controls the map button
        private static bool zoomed;
        public override void OnActivate()
        {   //This is what gets called when you click on the button
            UISoundPlayer.instance.PlayUISound(UISounds.buttonClick, 0.5f, 1f);
            LargeUI.ZoomMap(zoomed);
            zoomed = !zoomed;
            ForceUnlook();
        }
    }
    public class LargeUIBuyPassageButton : GoPointerButton
    {   //controls the buy passage button on the LargeUI
        public Port destination;
        public float maxTime;
        public float minTime;
        public float risk;
        public int cost;
        public int currency;

        public static LargeUIBuyPassageButton instance;
        
        private void Awake()
        {   //assign the instance
            instance = this;
            //create a random GameObject and attach the FerryTravel
            //component to it, so it calls its Awake() method
            GameObject go = new GameObject();
            go.AddComponent<FerryTravel>();
        }
        public override void OnActivate()
        {   //This is what gets called when you click on the button
            if (PlayerGold.currency[currency] > cost)
            {
                UISoundPlayer.instance.PlayGoldSound();
                LargeUI.CloseLargeUI();
                FerryTravel.instance.destination = instance.destination;
                FerryTravel.instance.maxTime = instance.maxTime;
                FerryTravel.instance.minTime = instance.minTime;
                FerryTravel.instance.risk = instance.risk;
                FerryTravel.instance.cost = instance.cost;
                FerryTravel.instance.currency = instance.currency;
                FerryTravel.instance.Travel();
                ForceUnlook();
            }
            else
            {
                UISoundPlayer.instance.PlayUISound(UISounds.buttonClick, 0.5f, 1f);
                //Debug.LogError("PassageDude: Not enough money...");
                ForceUnlook();  //not sure what this does, it's copied from the mission book button...
            }
        }
    }
}